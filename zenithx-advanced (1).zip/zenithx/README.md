# Inventory Management System

Inventory Management is now a responsive React/Express/tRPC/Drizzle web application converted from the original Java Swing + Maven + MySQL project. It keeps the original `categories`, `products`, and `stock_movements` table structure, uses the same sample records with non-destructive `INSERT IGNORE` seeding, and provides a professional navy, white, and light-blue operations dashboard.

## Run locally

From the project root:

```powershell
Copy-Item .env.example .env
# Edit .env: set your MySQL password and a long random JWT_SECRET.
pnpm install
pnpm db:migrate
pnpm dev
```

Keep `.env` in the project root, next to `package.json`; do not put it inside `drizzle`. Then open `http://localhost:3000/inventory-management` in your browser. You will land on the **Sign in** page. Click **Create an account** — the first account registered becomes the administrator.

Do not start the app with `pnpm exec tsx watch server/_core/index.ts`. Use the project script instead. It uses `cross-env`, so it works in Windows PowerShell as well as macOS/Linux:

```powershell
pnpm dev
```

You do not need the `mysql` command to run this project. `pnpm db:migrate` already confirmed that the project can connect to your MySQL server. The `mysql is not recognized` message only means the MySQL command-line tool is not in your Windows PATH.

For quality checks, use:

```bash
pnpm check
pnpm test
pnpm build
```

The managed MySQL connection is supplied through `DATABASE_URL`. Existing records are preserved; the seed migration only inserts the sample categories/products when their unique names or SKUs are absent.

## Application routes

| Route | Purpose |
| --- | --- |
| `/inventory-management` | Inventory Management dashboard metrics and product overview |
| `/` | Backward-compatible alias for Inventory Management |
| `/administration` | Application, platform, database, and user information |
| `/warehouse` | Stock totals, available products, reorder alerts, and stock table |
| `/products` | Search, add, edit, delete, refresh, and Indian Rupee pricing |
| `/categories` | Search, add, edit, delete, refresh, and relationship-safe deletion |
| `/pos` | Product selection, quantity validation, invoice total, stock deduction, and movement recording |

POS stock changes run inside a database transaction and reject invalid or over-available quantities. Category deletion is blocked when products still reference that category.

## Authentication and roles

Email + password accounts with signed, httpOnly session cookies (7 days). Passwords are hashed with scrypt; sign-in and sign-up are rate limited. Run `pnpm db:migrate` to add the new user columns (`0003_auth_and_roles`) — existing data is preserved.

| Role | Can do |
| --- | --- |
| **Admin** | Everything, plus the **Users** page (change roles, deactivate accounts). The first account to sign up is the admin. |
| **Manager** | Add/edit/delete products and categories, record stock movements. |
| **Staff** | View everything, make POS sales, edit own profile. |

| New route | Purpose |
| --- | --- |
| `/login`, `/signup` | Public auth pages (signed-in users are redirected away) |
| `/inventory-management` | Dashboard with sales trend, stock-by-category charts, restock list and recent activity |
| `/movements` | Stock movement audit trail; managers can record stock in/out/adjustments |
| `/users` | Admin-only user management |
| `/profile` | Edit name, change password |

All inventory API routes now require sign-in; role checks are enforced on the server, not just hidden in the UI. Set `JWT_SECRET` in `.env` (required when `NODE_ENV=production`).
